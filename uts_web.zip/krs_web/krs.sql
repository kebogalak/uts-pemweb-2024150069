-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 29, 2026 at 09:51 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `uts_web`
--

-- --------------------------------------------------------

--
-- Table structure for table `krs`
--

CREATE TABLE `krs` (
  `id` int(10) UNSIGNED NOT NULL,
  `nim` char(10) NOT NULL,
  `nama_mahasiswa` varchar(100) NOT NULL,
  `mata_kuliah` enum('Pemrograman Web','Kecerdasan Buatan','Analisis & Desain Berorientasi Objek','Komputasi Numerik','Desain & Analisis Algoritma') NOT NULL,
  `kelas` enum('A','B','C') NOT NULL,
  `sks` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `krs`
--

INSERT INTO `krs` (`id`, `nim`, `nama_mahasiswa`, `mata_kuliah`, `kelas`, `sks`, `created_at`, `deleted_at`) VALUES
(1, '2024150099', 'bobi saposi', 'Pemrograman Web', 'A', 3, '2026-05-27 11:17:01', '2026-05-27 11:26:07'),
(2, '2024150077', 'raihan cukimai', 'Kecerdasan Buatan', 'A', 3, '2026-05-27 11:17:26', '2026-05-27 11:26:05'),
(3, '2024150088', 'aditya', 'Komputasi Numerik', 'C', 2, '2026-05-27 11:21:42', '2026-05-27 11:26:03'),
(4, '2024150088', 'aditya', 'Pemrograman Web', 'A', 3, '2026-05-27 11:26:13', NULL),
(5, '2024150099', 'bobi saposi', 'Kecerdasan Buatan', 'B', 3, '2026-05-27 11:26:25', NULL),
(6, '2024150077', 'raihan cukimai', 'Komputasi Numerik', 'C', 2, '2026-05-27 11:26:41', '2026-05-27 15:20:21'),
(7, '2024150088', 'aditya', 'Pemrograman Web', 'A', 3, '2026-05-27 15:26:24', NULL),
(8, '2024150090', 'asssa', 'Kecerdasan Buatan', 'B', 3, '2026-05-27 15:30:12', NULL),
(9, '1111111111', 'raihan cukimai', 'Analisis & Desain Berorientasi Objek', 'A', 3, '2026-05-27 15:30:40', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `krs`
--
ALTER TABLE `krs`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `krs`
--
ALTER TABLE `krs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
