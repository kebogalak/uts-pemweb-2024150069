<?php
declare(strict_types=1);

// ==========================================
// 1. SESSION & SECURITY INITIALIZATION
// ==========================================
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// ==========================================
// 2. DATABASE CONNECTION (Singleton Pattern)
// ==========================================
class Database {
    private static ?PDO $pdo = null;

    public static function getConnection(): PDO {
        if (self::$pdo === null) {
            $dsn = "mysql:host=localhost;dbname=uts_web;charset=utf8mb4";
            try {
                self::$pdo = new PDO($dsn, 'root', '', [
                    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES   => false,
                ]);
            } catch (PDOException $e) {
                die("Koneksi database gagal: " . $e->getMessage());
            }
        }
        return self::$pdo;
    }
}

// ==========================================
// 3. REPOSITORY CLASS / DATA LOGIC (FIXED)
// ==========================================
class KrsRepository {
    private PDO $db;

    public function __construct() {
        $this->db = Database::getConnection();
    }

    // Mengambil semua data KRS yang belum di-soft delete
    public function getAllActive(string $search = ''): array {
        if ($search !== '') {
            // Menggunakan tanda tanya (?) agar parameter terbaca berurutan dan bebas dari error HY093
            $stmt = $this->db->prepare(
                "SELECT * FROM krs WHERE deleted_at IS NULL AND (nama_mahasiswa LIKE ? OR nim LIKE ?) ORDER BY id DESC"
            );
            
            $paramSearch = "%{$search}%";
            $stmt->execute([$paramSearch, $paramSearch]);
            return $stmt->fetchAll();
        }
        $stmt = $this->db->query("SELECT * FROM krs WHERE deleted_at IS NULL ORDER BY id DESC");
        return $stmt->fetchAll();
    }

    // Menyimpan data pengambilan KRS baru
    public function create(array $data): bool {
        $stmt = $this->db->prepare(
            "INSERT INTO krs (nim, nama_mahasiswa, mata_kuliah, kelas, sks) 
             VALUES (:nim, :nama_mahasiswa, :mata_kuliah, :kelas, :sks)"
        );
        return $stmt->execute($data);
    }

    // Melakukan Soft Delete pembatalan KRS
    public function softDelete(int $id): bool {
        $stmt = $this->db->prepare("UPDATE krs SET deleted_at = NOW() WHERE id = :id");
        return $stmt->execute([':id' => $id]);
    }
}

// ==========================================
// 4. CONTROLLER / FORM HANDLING & VALIDATION
// ==========================================
$repo = new KrsRepository();
$errors = [];
$old = ['nim' => '', 'nama_mahasiswa' => '', 'mata_kuliah' => '', 'kelas' => ''];

// Array bantuan untuk pemetaan SKS otomatis berdasarkan mata kuliah
$listSks = [
    'Pemrograman Web' => 3,
    'Kecerdasan Buatan' => 3,
    'Analisis & Desain Berorientasi Objek' => 3,
    'Komputasi Numerik' => 2,
    'Desain & Analisis Algoritma' => 3
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validasi Keamanan Token CSRF
    if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        die("Validasi keamanan CSRF gagal! Request ilegal terdeteksi.");
    }

    // Aksi 1: Batalkan/Hapus KRS (Soft Delete)
    if (isset($_POST['action']) && $_POST['action'] === 'delete') {
        $id = (int)$_POST['id'];
        $repo->softDelete($id);
        header("Location: index.php");
        exit;
    }

    // Aksi 2: Input KRS Baru
    if (isset($_POST['action']) && $_POST['action'] === 'create') {
        $old['nim']            = trim($_POST['nim'] ?? '');
        $old['nama_mahasiswa'] = trim($_POST['nama_mahasiswa'] ?? '');
        $old['mata_kuliah']    = trim($_POST['mata_kuliah'] ?? '');
        $old['kelas']          = trim($_POST['kelas'] ?? '');

        // Validasi Input Server-side
        if (!preg_match('/^[0-9]{10}$/', $old['nim'])) {
            $errors['nim'] = 'NIM mahasiswa harus tepat 10 digit angka.';
        }
        if (empty($old['nama_mahasiswa']) || strlen($old['nama_mahasiswa']) < 3) {
            $errors['nama_mahasiswa'] = 'Nama mahasiswa wajib diisi (minimal 3 karakter).';
        }
        if (!array_key_exists($old['mata_kuliah'], $listSks)) {
            $errors['mata_kuliah'] = 'Mata kuliah yang dipilih tidak valid.';
        }
        if (!in_array($old['kelas'], ['A', 'B', 'C'], true)) {
            $errors['kelas'] = 'Pilihan kelas tidak valid.';
        }

        // Jika tidak ada error, simpan data ke database
        if (empty($errors)) {
            $repo->create([
                ':nim'            => $old['nim'],
                ':nama_mahasiswa' => $old['nama_mahasiswa'],
                ':mata_kuliah'    => $old['mata_kuliah'],
                ':kelas'          => $old['kelas'],
                ':sks'            => $listSks[$old['mata_kuliah']]
            ]);
            header("Location: index.php");
            exit;
        }
    }
}

// Fitur Pencarian Data KRS
$search = $_GET['q'] ?? '';
$daftarKrs = $repo->getAllActive($search);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SIAKAD — Input KRS Mahasiswa</title>
    <style>
        :root {
            --primary: #0284c7;
            --bg: #f8fafc;
            --surface: #ffffff;
            --text: #0f172a;
            --error: #ef4444;
            --border: #e2e8f0;
        }
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'Segoe UI', system-ui, sans-serif; background: var(--bg); color: var(--text); padding: 2rem; }
        
        .container { max-width: 1200px; margin: 0 auto; display: flex; flex-direction: column; gap: 2rem; }
        header { border-bottom: 3px solid var(--primary); padding-bottom: 1rem; }
        header h1 { color: var(--primary); }
        
        .main-layout { display: flex; flex-direction: column; gap: 2rem; }
        @media(min-width: 768px) {
            .main-layout { display: grid; grid-template-columns: 380px 1fr; align-items: start; }
        }

        form.card-form { background: var(--surface); padding: 1.75rem; border-radius: 0.5rem; border: 1px solid var(--border); display: flex; flex-direction: column; gap: 1.25rem; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
        .form-group { display: flex; flex-direction: column; gap: 0.35rem; }
        label { font-weight: 600; font-size: 0.9rem; }
        input, select { padding: 0.6rem; border: 1px solid var(--border); border-radius: 0.375rem; width: 100%; font-size: 0.95rem; }
        input:focus, select:focus { border-color: var(--primary); outline: none; box-shadow: 0 0 0 3px rgba(2, 132, 199, 0.15); }
        .error { color: var(--error); font-size: 0.85rem; margin-top: 0.25rem; }

        .grid-krs { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 1.5rem; }
        .card-krs { background: var(--surface); border: 1px solid var(--border); border-radius: 0.5rem; padding: 1.5rem; display: flex; flex-direction: column; gap: 0.5rem; box-shadow: 0 1px 3px rgba(0,0,0,0.05); }
        .card-krs h3 { font-size: 1.15rem; color: #1e3a8a; border-bottom: 1px dashed var(--border); padding-bottom: 0.5rem; }
        
        .badge-container { display: flex; gap: 0.5rem; margin-top: 0.5rem; }
        .badge { font-size: 0.8rem; padding: 0.25rem 0.6rem; border-radius: 0.25rem; font-weight: bold; }
        .badge-sks { background: #e0f2fe; color: #0369a1; }
        .badge-kelas { background: #fef3c7; color: #d97706; }

        .btn { padding: 0.6rem 1.2rem; background: var(--primary); color: white; border: none; border-radius: 0.375rem; cursor: pointer; font-weight: 600; text-align: center; font-size: 0.95rem; transition: background 0.2s; }
        .btn:hover { background: #026ca3; }
        .btn-danger { background: var(--error); }
        .btn-danger:hover { background: #dc2626; }
    </style>
</head>
<body>

<div class="container">
    <header>
        <h1>SIAKAD — Portal KRS Mahasiswa</h1>
        <p>Program Studi Teknik Informatika — FASTIKOM UNSIQ</p>
    </header>

    <div class="main-layout">
        <section>
            <h2 style="margin-bottom: 1rem;">Isi Rencana Studi</h2>
            <form method="POST" action="index.php" class="card-form">
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                <input type="hidden" name="action" value="create">

                <div class="form-group">
                    <label for="nim">NIM Mahasiswa (10 Digit)</label>
                    <input type="text" id="nim" name="nim" placeholder="Contoh: 2025010001" value="<?= htmlspecialchars($old['nim']) ?>" required>
                    <?php if(isset($errors['nim'])): ?><span class="error"><?= $errors['nim'] ?></span><?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="nama_mahasiswa">Nama Lengkap Mahasiswa</label>
                    <input type="text" id="nama_mahasiswa" name="nama_mahasiswa" placeholder="Nama Lengkap" value="<?= htmlspecialchars($old['nama_mahasiswa']) ?>" required>
                    <?php if(isset($errors['nama_mahasiswa'])): ?><span class="error"><?= $errors['nama_mahasiswa'] ?></span><?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="mata_kuliah">Pilih Mata Kuliah</label>
                    <select id="mata_kuliah" name="mata_kuliah" required>
                        <option value="">-- Pilih Mata Kuliah --</option>
                        <?php foreach($listSks as $mk => $sks): ?>
                            <option value="<?= $mk ?>" <?= $old['mata_kuliah'] === $mk ? 'selected' : '' ?>><?= $mk ?> (<?= $sks ?> SKS)</option>
                        <?php endforeach; ?>
                    </select>
                    <?php if(isset($errors['mata_kuliah'])): ?><span class="error"><?= $errors['mata_kuliah'] ?></span><?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="kelas">Pilih Kelas</label>
                    <select id="kelas" name="kelas" required>
                        <option value="">-- Pilih Kelas --</option>
                        <option value="A" <?= $old['kelas'] === 'A' ? 'selected' : '' ?>>Kelas A</option>
                        <option value="B" <?= $old['kelas'] === 'B' ? 'selected' : '' ?>>Kelas B</option>
                        <option value="C" <?= $old['kelas'] === 'C' ? 'selected' : '' ?>>Kelas C</option>
                    </select>
                    <?php if(isset($errors['kelas'])): ?><span class="error"><?= $errors['kelas'] ?></span><?php endif; ?>
                </div>

                <button type="submit" class="btn" style="margin-top: 0.5rem;">Ambil Mata Kuliah</button>
            </form>
        </section>

        <section>
            <div style="display: flex; flex-wrap: wrap; justify-content: space-between; align-items: center; margin-bottom: 1rem; gap: 1rem;">
                <h2>Daftar Pengambilan KRS Terkini</h2>
                <form method="GET" action="index.php" style="display: flex; gap: 0.5rem; max-width: 320px; width: 100%;">
                    <input type="text" name="q" placeholder="Cari berdasarkan NIM/Nama..." value="<?= htmlspecialchars($search) ?>">
                    <button type="submit" class="btn">Cari</button>
                </form>
            </div>

            <div class="grid-krs">
                <?php if (empty($daftarKrs)): ?>
                    <p style="grid-column: 1/-1; color: #64748b; font-style: italic;">Belum ada rencana studi mahasiswa yang diinputkan.</p>
                <?php endif; ?>

                <?php foreach ($daftarKrs as $krs): ?>
                    <div class="card-krs">
                        <h3><?= htmlspecialchars($krs['mata_kuliah']) ?></h3>
                        <p style="font-weight: 600; font-size: 0.95rem; margin-top: 0.25rem;">
                            <?= htmlspecialchars($krs['nama_mahasiswa']) ?>
                        </p>
                        <p style="font-size: 0.85rem; color: #64748b;">NIM: <?= htmlspecialchars($krs['nim']) ?></p>
                        
                        <div class="badge-container">
                            <span class="badge badge-sks"><?= (int)$krs['sks'] ?> SKS</span>
                            <span class="badge badge-kelas">Kelas <?= htmlspecialchars($krs['kelas']) ?></span>
                        </div>

                        <form method="POST" action="index.php" style="margin-top: 1rem;" onsubmit="return confirm('Apakah Anda yakin ingin membatalkan rencana studi untuk mata kuliah ini?')">
                            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                            <input type="hidden" name="id" value="<?= $krs['id'] ?>">
                            <input type="hidden" name="action" value="delete">
                            <button type="submit" class="btn btn-danger" style="width: 100%; font-size: 0.85rem; padding: 0.4rem 0.8rem;">Batalkan Ambil</button>
                        </form>
                    </div>
                <?php endforeach; ?>
            </div>
        </section>
    </div>
</div>

</body>
</html>